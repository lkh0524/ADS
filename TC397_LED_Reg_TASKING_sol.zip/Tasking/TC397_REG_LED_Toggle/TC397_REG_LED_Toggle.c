/*****************************************************
 *
 * TC397_REG_LED_Toggle.c
 *
 * Description : Hello World in C, ANSI-style
 *
 */
#include "IfxPort_reg.h"
#include <stdio.h>
void delay(void);

int main(void)
{
	P13_IOCR0.B.PC0=0x10;
	P13_IOCR0.B.PC1=0x10;
	P13_IOCR0.B.PC2=0x10;
	P13_IOCR0.B.PC3=0x10;

	while(1)
	{
		P13_OUT.B.P0=~P13_OUT.B.P0;
		P13_OUT.B.P1=~P13_OUT.B.P1;
		P13_OUT.B.P2=~P13_OUT.B.P2;
		P13_OUT.B.P3=~P13_OUT.B.P3;
		delay();
	}
}
void delay(void)
{
	int i,j;
	for(i=0;i<15000;i++)
		for(j=0;j<15000;j++)
			__nop();
}
