/******************************************************************************
**                                                                           **
** Copyright (C) Infineon Technologies (2017)                                **
**                                                                           **
** All rights reserved.                                                      **
**                                                                           **
** This document contains proprietary information belonging to Infineon      **
** Technologies. Passing on and copying of this document, and communication  **
** of its contents is not permitted without prior written authorization.     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  FILENAME   : DemoApp.c                                                   **
**                                                                           **
**  VERSION    : 2.0.0                                                       **
**                                                                           **
**  DATE       : 2017-03-07                                                  **
**                                                                           **
**  VARIANT    : NA                                                          **
**                                                                           **
**  PLATFORM   : Infineon AURIX2G                                            **
**                                                                           **
**  AUTHOR      : DL-AUTOSAR-Engineering                                     **
**                                                                           **
**  VENDOR      : Infineon Technologies                                      **
**                                                                           **
**  DESCRIPTION : This file contains                                         **
**                - DemoApp Framework for MCAL driver Demo Applications      **
**                                                                           **
**  MAY BE CHANGED BY USER [yes/no]: Yes                                     **
**                                                                           **
******************************************************************************/

/*******************************************************************************
**                      Includes                                              **
*******************************************************************************/
#include "Std_Types.h"
#include "IfxCpu_reg.h"
#include "Test_Print.h"
#include "Test_Time.h"
#include "Mcu.h"
#include "Port.h"
#include "DemoApp.h"

/*******************************************************************************
**               Private Macro Definitions                                    **
*******************************************************************************/

/*******************************************************************************
**                      Private Type Definitions                              **
*******************************************************************************/

/*******************************************************************************
**                      Private Function Declarations                         **
*******************************************************************************/
void DemoApp_Init(void);
void DemoApp_Mcu_Init(void);
void DemoApp_Port_Init(void);

/*******************************************************************************
**                      Global Variable Definitions                           **
*******************************************************************************/
DemoApp_MenuType const *DemoApp_Menu_p;
char szString[80];
uint32 str_pos; /* position of the pointer in the receive buffer */
uint8 DemoApp_FlsInitDone; /* Flag to check FLS init is already called */
#define MCU_START_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED
#include "Mcu_MemMap.h"

extern const Mcu_ConfigType Mcu_Config;

#define MCU_STOP_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED
#include "Mcu_MemMap.h"

#define PORT_START_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED
#include "Port_MemMap.h"

extern const Port_ConfigType Port_Config;

#define PORT_STOP_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED
#include "Port_MemMap.h"

/*******************************************************************************
**                      Private  Constant Definitions                         **
*******************************************************************************/
/*******************************************************************************
**                     Private  Variable Definitions                          **
*******************************************************************************/
/*******************************************************************************
**                      Global Function Definitions                           **
*******************************************************************************/
/*******************************************************************************
** Syntax : void DemoApp_Init(void)                                           **
**                                                                            **
** Service ID:   : NA                                                         **
**                                                                            **
** Sync/Async:   : Synchronous                                                **
**                                                                            **
** Reentrancy:   : Reentrant                                                  **
**                                                                            **
** Parameters (in): none                                                      **
**                                                                            **
** Parameters (out): none                                                     **
**                                                                            **
** Return value: none                                                         **
**                                                                            **
** Description : Initialise Mcu and Port module to enable serial communication**
*******************************************************************************/
void DemoApp_Init(void)
{
  DemoApp_Mcu_Init();
  DemoApp_Port_Init();
}

/*******************************************************************************
** Syntax : void DemoApp_Mcu_Init(void)                                       **
**                                                                            **
** Service ID:   : NA                                                         **
**                                                                            **
** Sync/Async:   : Synchronous                                                **
**                                                                            **
** Reentrancy:   : Reentrant                                                  **
**                                                                            **
** Parameters (in): none                                                      **
**                                                                            **
** Parameters (out): none                                                     **
**                                                                            **
** Return value: none                                                         **
**                                                                            **
** Description : Initialise Mcu module to enable clocks                       **
*******************************************************************************/
void DemoApp_Mcu_Init(void)
{
  const Mcu_ConfigType * ConfigPtr = NULL_PTR;
  volatile Mcu_ClockType ClockID = 0;
  Std_ReturnType InitClockRetVal;
  Mcu_PllStatusType Mcu_GetPllStatusRetVal = MCU_PLL_STATUS_UNDEFINED;

  ConfigPtr = &Mcu_Config;
  Mcu_Init(ConfigPtr);
  InitClockRetVal = Mcu_InitClock(ClockID);

  if(InitClockRetVal == E_OK)
  {
    do
    {
      Mcu_GetPllStatusRetVal = Mcu_GetPllStatus ();
    } while(Mcu_GetPllStatusRetVal != MCU_PLL_LOCKED);

    #if (MCU_DISTRIBUTE_PLL_CLOCK_API == STD_ON)
    Mcu_DistributePllClock ();
    #endif
  }
}

/*******************************************************************************
** Syntax : void DemoApp_Port_Init(void)                                      **
**                                                                            **
** Service ID:   : NA                                                         **
**                                                                            **
** Sync/Async:   : Synchronous                                                **
**                                                                            **
** Reentrancy:   : Reentrant                                                  **
**                                                                            **
** Parameters (in): none                                                      **
**                                                                            **
** Parameters (out): none                                                     **
**                                                                            **
** Return value: none                                                         **
**                                                                            **
** Description : Initialise Port module to enable serial communication        **
*******************************************************************************/
void DemoApp_Port_Init(void)
{
  const Port_ConfigType * ConfigPtr = NULL_PTR;
  ConfigPtr = &Port_Config;
  Port_Init(ConfigPtr);
}
