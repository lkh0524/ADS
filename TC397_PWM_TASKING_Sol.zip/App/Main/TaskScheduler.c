// ------------------------------------- DISCLAIMER -----------------------------------------//
// THE INFORMATION GIVEN IN THE DOCUMENTS (APPLICATION NOTE, SOFTWARE PROGRAM ETC.)
// IS GIVEN AS A HINT FOR THE IMPLEMENTATION OF THE INFINEON TECHNOLOGIES COMPONENT ONLY
// AND SHALL NOT BE REGARDED AS ANY DESCRIPTION OR WARRANTY OF A CERTAIN FUNCTIONALITY,
// CONDITION OR QUALITY OF THE INFINEON TECHNOLOGIES COMPONENT.
// YOU MUST VERIFY ANY FUNCTION DESCRIBED IN THE DOCUMENTS IN THE REAL APPLICATION.
// INFINEON TECHNOLOGIES AG HEREBY DISCLAIMS ANY AND ALL WARRANTIES AND LIABILITIES OF ANY KIND
// (INCLUDING WITHOUT LIMITATION WARRANTIES OF NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS
// OF ANY THIRD PARTY) WITH RESPECT TO ANY AND ALL INFORMATION GIVEN IN THE DOCUMENTS.
// ------------------------------------------------ -----------------------------------------//
/*******************************************************************************
**                                                                            **
** Copyright (C) Infineon Technologies (2013)                                 **
**                                                                            **
** All rights reserved.                                                       **
**                                                                            **
** This document contains proprietary information belonging to Infineon       **
** Technologies. Passing on and copying of this document, and communication   **
** of its contents is not permitted without prior written authorization.      **
**                                                                            **
********************************************************************************
**                                                                            **
**  FILENAME  : TaskScheduler.c                                               **
**                                                                            **
**  VERSION   : 1.0.0                                                         **
**                                                                            **
**  DATE      : 2015-06-26                                                    **
**                                                                            **
**  PLATFORM  : AURIX, MCAL                                                   **
**                                                                            **
**  COMPILER  : Tasking			                                              **
**                                                                            **
**  VENDOR    : Infineon Technologies                                         **
**                                                                            **
**  DESCRIPTION  : This file contains                                         **
**                                                                            **
**  SPECIFICATION(S) :                                                        **
**                                                                            **
**  MAY BE CHANGED BY USER [Yes/No]: Yes                                      **
*******************************************************************************/

/*******************************************************************************
**                      Author(s) Identity                                    **
********************************************************************************
**                                                                            **
** Initials     Name                                                          **
** ---------------------------------------------------------------------------**
*******************************************************************************/

//****************************************************************************
// @Project Includes
//****************************************************************************



#include "TaskScheduler.h"


#include "Gpt.h"
#include "IfxPort_reg.h"
//****************************************************************************
// @Defines
//****************************************************************************

//****************************************************************************
// @Prototypes Of Local Functions
//****************************************************************************

#if(SYSTEM_TICK==100)
static	void TaskScheduler_100us(void);
#endif
#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
static	void TaskScheduler_200us(void);
#endif
static	void TaskScheduler_1ms(void);
static	void TaskScheduler_5ms(void);
static	void TaskScheduler_10ms(void);
static	void TaskScheduler_20ms(void);
static	void TaskScheduler_50ms(void);
static	void TaskScheduler_100ms(void);
static	void TaskScheduler_TaskCalculation(void);


//****************************************************************************
// @Global Variables
//****************************************************************************
TASK_CONTROL	TaskControl;

//****************************************************************************
// @ Imported Global Variables
//****************************************************************************

//****************************************************************************
// @ Imported Global Functions
//****************************************************************************


//*********************************************************************************************
// @Function	 	void Gpt_Notification_SystemTick(void)
// @Description   	Gpt notification for system tick generation // Use TOM0_2
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
void Gpt_Notification_SystemTick(void)
{

	TaskControl.B.TickCount++;
	TaskControl.B.Enable = 1;

} /* Gpt_Notification_SystemTick() */

//*********************************************************************************************
// @Function	 	void TaskScheduler_Initialization(unsigned int maxTask)
// @Description   	Initialize task scheduler related parameters.
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
void TaskScheduler_Initialization(unsigned int maxTask)
{
	TaskControl.U = 0;

	TaskControl.B.Tick		= SYSTEM_TICK;
	TaskControl.B.TaskMax 	= maxTask;

	// Enable notification for system tick generation
	Gpt_EnableNotification(GptConf_GptChannelConfiguration_System_Tick);

	// Start timer for system tick generation
	Gpt_StartTimer(GptConf_GptChannelConfiguration_System_Tick, SYSTEM_TICK_TIMER_PERIOD);


} // End of TaskScheduler_Initialization()


//*********************************************************************************************
// @Function	 	static	void TaskScheduler_TaskCalculation(void)
// @Description   	Calculate task job to be executed.
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
static void TaskScheduler_TaskCalculation(void)
{
	#if(SYSTEM_TICK == 100)
	if((TaskControl.B.TickCount % TASK_100us) 	== 0) TaskControl.B.TaskRun = TASK_100us;
	#endif
	#if(SYSTEM_TICK == 100 || SYSTEM_TICK == 200)
	if((TaskControl.B.TickCount % TASK_200us) 	== 0) TaskControl.B.TaskRun = TASK_200us;
	#endif
	if((TaskControl.B.TickCount % TASK_1ms)		== 0) TaskControl.B.TaskRun = TASK_1ms;
	if((TaskControl.B.TickCount % TASK_5ms) 	== 0) TaskControl.B.TaskRun = TASK_5ms;
	if((TaskControl.B.TickCount % TASK_10ms)	== 0) TaskControl.B.TaskRun = TASK_10ms;
	if((TaskControl.B.TickCount % TASK_20ms)	== 0) TaskControl.B.TaskRun = TASK_20ms;
	if((TaskControl.B.TickCount % TASK_50ms)	== 0) TaskControl.B.TaskRun = TASK_50ms;
	if((TaskControl.B.TickCount % TASK_100ms)	== 0) TaskControl.B.TaskRun = TASK_100ms;

}  // End of TaskScheduler_TaskCalculation()

//*********************************************************************************************
// @Function	 	void TaskScheduler_ActivateTask(void)
// @Description   	Execute task job.
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
void TaskScheduler_ActivateTask(void)
{
	if(TaskControl.B.TickCount > TaskControl.B.TaskMax)		TaskControl.B.TickCount = 1;

	if(TaskControl.B.Enable == 1)
	{
		TaskControl.B.Enable = 0;   		// Stop task scheduler

		TaskScheduler_TaskCalculation();

		switch(TaskControl.B.TaskRun)
		{
				#if(SYSTEM_TICK==100)
				case TASK_100us:
								TaskScheduler_100us();
								break;
				#endif
				#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
				case TASK_200us:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								TaskScheduler_200us();
								break;
				#endif
				case TASK_1ms:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
								TaskScheduler_200us();
								#endif
								TaskScheduler_1ms();
								break;
				case TASK_5ms:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
								TaskScheduler_200us();
								#endif
								TaskScheduler_1ms();
								TaskScheduler_5ms();
								break;
				case TASK_10ms:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
								TaskScheduler_200us();
								#endif
								TaskScheduler_1ms();
								TaskScheduler_5ms();
								TaskScheduler_10ms();
								break;
				case TASK_20ms:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
								TaskScheduler_200us();
								#endif
								TaskScheduler_1ms();
								TaskScheduler_5ms();
								TaskScheduler_10ms();
								TaskScheduler_20ms();
								break;
				case TASK_50ms:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
								TaskScheduler_200us();
								#endif
								TaskScheduler_1ms();
								TaskScheduler_5ms();
								TaskScheduler_10ms();
								TaskScheduler_50ms();
								break;
				case TASK_100ms:
								#if(SYSTEM_TICK==100)
								TaskScheduler_100us();
								#endif
								#if(SYSTEM_TICK==100 || SYSTEM_TICK==200)
								TaskScheduler_200us();
								#endif
								TaskScheduler_1ms();
								TaskScheduler_5ms();
								TaskScheduler_10ms();
								TaskScheduler_20ms();
								TaskScheduler_50ms();
								TaskScheduler_100ms();
								break;

			default:		break;
		}
	}
}//end of TaskScheduler_ActivateTask()

#if(SYSTEM_TICK == 100)
///////////////   100us Task Job    //////////////////
static	void TaskScheduler_100us(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_100us();
#endif

#if(SYSTEM_TICK == 100 || SYSTEM_TICK == 200)
///////////////   200us Task Job    //////////////////
static	void TaskScheduler_200us(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_200us();
#endif

///////////////   1ms Task Job    //////////////////
static	void TaskScheduler_1ms(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_1ms();


///////////////   5ms Task Job    //////////////////
static	void TaskScheduler_5ms(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_5ms();


///////////////   10ms Task Job    /////////////////
static	void TaskScheduler_10ms(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_10ms();

///////////////   20ms Task Job    /////////////////
static	void TaskScheduler_20ms(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_20ms();


///////////////   50ms Task Job    /////////////////
static	void TaskScheduler_50ms(void)
{
	__nop();
	__nop();
} // End of TaskScheduler_50ms();

///////////////   100ms Task Job    /////////////////
static	void TaskScheduler_100ms(void)
{
	P33_OUT.B.P4 = !P33_OUT.B.P4;
} // End of TaskScheduler_100ms();

