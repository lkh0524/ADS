/*******************************************************************************
**                                                                            **
** Copyright (C) Infineon Technologies (2016)                                 **
**                                                                            **
** All rights reserved.                                                       **
**                                                                            **
** This document contains proprietary information belonging to Infineon       **
** Technologies. Passing on and copying of this document, and communication   **
** of its contents is not permitted without prior written authorization.      **
**                                                                            **
********************************************************************************
**                                                                            **
**  FILENAME     : Cpu0_Main.c                                                **
**                                                                            **
**  VERSION      : 0.0.1                                                      **
**                                                                            **
**  DATE         : 2016-08-17                                                 **
**                                                                            **
**  VARIANT      : NA                                                         **
**                                                                            **
**  PLATFORM     : Infineon AURIX2G                                           **
**                                                                            **
**  AUTHOR       : DL-AUTOSAR-Engineering                                     **
**                                                                            **
**  VENDOR       : Infineon Technologies                                      **
**                                                                            **
**  DESCRIPTION  : Example Cpu0 Main startup file                             **
**                                                                            **
**  SPECIFICATION(S) : NA                                                     **
**                                                                            **
**  MAY BE CHANGED BY USER : yes                                              **
**                                                                            **
*******************************************************************************/
/*******************************************************************************
**                      Includes                                              **
*******************************************************************************/
#include "Ifx_Ssw_Infra.h"
#include "IFX_Os.h"

#include "TaskScheduler.h"
#include "IfxSrc_reg.h"
#include "DemoApp.h"
#include "Gpt.h"
#include "Irq.h"
#include "Pwm_17_GtmCcu6.h"
/*******************************************************************************
**                      Imported Compiler Switch Check                        **
*******************************************************************************/

/*******************************************************************************
**                      Private Macro Definitions                             **
*******************************************************************************/

/*******************************************************************************
**                      Private Type Definitions                              **
*******************************************************************************/

/*******************************************************************************
**                      Private Function Declarations                         **
*******************************************************************************/

/*******************************************************************************
**                      Global Constant Definitions                           **
*******************************************************************************/

/*******************************************************************************
**                      Global Variable Definitions                           **
*******************************************************************************/

/*******************************************************************************
**                      Private Constant Definitions                          **
*******************************************************************************/

/*******************************************************************************
**                      Private Variable Definitions                          **
*******************************************************************************/

/*******************************************************************************
**                      Global Functon Definitions                            **
*******************************************************************************/

uint16 duty = 750;

void core0_main (void)
{

  unsigned short cpuWdtPassword;
  unsigned short safetyWdtPassword;


  ENABLE();
  /*
   * !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
   * Enable the watchdog in the demo if it is required and also service the watchdog periodically
   * */
  cpuWdtPassword = Ifx_Ssw_getCpuWatchdogPassword(&MODULE_SCU.WDTCPU[0]);
  safetyWdtPassword = Ifx_Ssw_getSafetyWatchdogPassword();
  Ifx_Ssw_disableCpuWatchdog(&MODULE_SCU.WDTCPU[0], cpuWdtPassword);
  Ifx_Ssw_disableSafetyWatchdog(safetyWdtPassword);


  DemoApp_Init(); 		 // Initialize Mcu and Port module
  Gpt_Init(&Gpt_Config); // Initialize Gpt module


  /* Initialize interrupt request configurations */
  IrqGtm_Init();
  SRC_GTMTOM00.B.SRE = 1;


  TaskScheduler_Initialization(TASK_100ms);

  Pwm_17_GtmCcu6_SetDutyCycle(Pwm_17_GtmCcu6Conf_PwmChannel_PwmChannel_0,duty);
  Pwm_17_GtmCcu6_SetDutyCycle(Pwm_17_GtmCcu6Conf_PwmChannel_PwmChannel_1,duty);
  Pwm_17_GtmCcu6_SetDutyCycle(Pwm_17_GtmCcu6Conf_PwmChannel_PwmChannel_2,duty);


	while(1)
	{
		__nop();
		TaskScheduler_ActivateTask();
		__nop();

	}

}

