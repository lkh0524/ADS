// ------------------------------------- DISCLAIMER -----------------------------------------//
// THE INFORMATION GIVEN IN THE DOCUMENTS (APPLICATION NOTE, SOFTWARE PROGRAM ETC.)
// IS GIVEN AS A HINT FOR THE IMPLEMENTATION OF THE INFINEON TECHNOLOGIES COMPONENT ONLY
// AND SHALL NOT BE REGARDED AS ANY DESCRIPTION OR WARRANTY OF A CERTAIN FUNCTIONALITY,
// CONDITION OR QUALITY OF THE INFINEON TECHNOLOGIES COMPONENT.
// YOU MUST VERIFY ANY FUNCTION DESCRIBED IN THE DOCUMENTS IN THE REAL APPLICATION.
// INFINEON TECHNOLOGIES AG HEREBY DISCLAIMS ANY AND ALL WARRANTIES AND LIABILITIES OF ANY KIND
// (INCLUDING WITHOUT LIMITATION WARRANTIES OF NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS
// OF ANY THIRD PARTY) WITH RESPECT TO ANY AND ALL INFORMATION GIVEN IN THE DOCUMENTS.
// ------------------------------------------------ -----------------------------------------//
/*******************************************************************************
**                                                                            **
** Copyright (C) Infineon Technologies (2013)                                 **
**                                                                            **
** All rights reserved.                                                       **
**                                                                            **
** This document contains proprietary information belonging to Infineon       **
** Technologies. Passing on and copying of this document, and communication   **
** of its contents is not permitted without prior written authorization.      **
**                                                                            **
********************************************************************************
**                                                                            **
**  FILENAME  : TaskScheduler.h                                               **
**                                                                            **
**  VERSION   : 1.0.0                                                         **
**                                                                            **
**  DATE      : 2015-06-26                                                    **
**                                                                            **
**  PLATFORM  : Aurix                                                         **
**                                                                            **
**  COMPILER  : Tasking                                 		              **
**                                                                            **
**  VENDOR    : Infineon Technologies                                         **
**                                                                            **
**  DESCRIPTION  : This file contains                                         **
**                                                                            **
**  SPECIFICATION(S) :                                                        **
**                                                                            **
**  MAY BE CHANGED BY USER [Yes/No]: Yes                                      **
*******************************************************************************/
/*******************************************************************************
**                      Author(s) Identity                                    **
********************************************************************************
**                                                                            **
** Initials     Name                                                          **
** ---------------------------------------------------------------------------**
*******************************************************************************/

#ifndef _TASKSCHEDULER_H_
#define _TASKSCHEDULER_H_

//****************************************************************************
// @Macros
//****************************************************************************

#define SYSTEM_TICK					(100U)		// [usec]
#define	SYSTEM_TICK_TIMER_CLOCK		(100)		// [MHz] e.g GTM_FIXED_CLOCK0 is used : 100MHz

#define SYSTEM_TICK_TIMER_PERIOD	(SYSTEM_TICK * SYSTEM_TICK_TIMER_CLOCK)

//****************************************************************************
// @Typedefs
//****************************************************************************
typedef union
{
	unsigned int	U;
	struct
	{
		unsigned int	Enable			:16;	// Task scheduler enable bit
		unsigned int	TickCount		:16;	// Software counter for system tick
		unsigned int	Tick			:16;	// Selected System tick
		unsigned int	TaskRun			:16;	// Current running task
		unsigned int	TaskMax			:16;	// Maximum repeated time task
	}B;
} TASK_CONTROL;


typedef enum
{

	#if(SYSTEM_TICK == 100)
	TASK_100us	= 1,
	TASK_200us	= 2,
	TASK_1ms	= 10,
	TASK_5ms	= 50,
	TASK_10ms	= 100,
	TASK_20ms	= 200,
	TASK_50ms	= 500,
	TASK_100ms	= 1000
	#elif(SYSTEM_TICK == 200)
	TASK_200us	= 1,
	TASK_1ms	= 5,
	TASK_5ms	= 25,
	TASK_10ms	= 50,
	TASK_20ms	= 100,
	TASK_50ms	= 250,
	TASK_100ms	= 500
	#elif(SYSTEM_TICK == 1000)
	TASK_1ms	= 1,
	TASK_5ms	= 5,
	TASK_10ms	= 10,
	TASK_20ms	= 20,
	TASK_50ms	= 50,
	TASK_100ms	= 100

	#endif
} NO_OF_TICK_COUNT_FOR_TASK;



//****************************************************************************
// @Prototypes Of Global Functions
//****************************************************************************
extern 	void TaskScheduler_Initialization(unsigned int maxTask);
extern	void TaskScheduler_ActivateTask(void);



#endif  // ifndef _TASKSCHEDULER_H_


